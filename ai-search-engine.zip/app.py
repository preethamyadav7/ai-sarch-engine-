from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

def ai_search(query):
    # Simple placeholder AI response
    return f"AI result for: {query}"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/search", methods=["POST"])
def search():
    data = request.json
    query = data.get("query")
    result = ai_search(query)
    return jsonify({"result": result})

if __name__ == "__main__":
    app.run(debug=True)